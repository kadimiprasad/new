"""math_module"""
import math
import logging

logging.basicConfig(filename="new_log.log", level=logging.ERROR,
                    format='%(asctime)s %(message)s',
                    filemode='w')

"""function_logarithm"""


def logarithm(x):
    try:
        if x > 0:
            k = math.log10(x)
            return k
        elif isinstance(x, int):
            raise TypeError
        else:
            raise ValueError
    except ValueError as value_error:
        logging.error(value_error.message)
        print "enter positive values"
    except TypeError as type_error:
        logging.error(type_error.message)
        print "enter integer or float"
