import math
from logg import *


class Logarithm1(object):
    def __init__(self, x):
        self.x = x

    def logarithm(self, x):
        try:
            if x > 0:
                k = math.log10(x)
                return k
            elif type(x)!= int:
                raise TypeError
            else:
                raise ValueError
        except ValueError as t:
            logger.error(t.message)
            print ("enter positive values")
        except TypeError as v:
            logger.error(v.message)
            print("enter integer or float")


# x = input("enter the number")
# c = Logarithm1(x)
# c.logarithm(x)

