from src.code.log import logarithm
import sys
def main():
    number = float(sys.argv[1])
    print logarithm(number)
