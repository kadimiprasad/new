from log import *
number = input("enter the number")


if __name__ == '__main__':
    log = Logarithm1(number)
    print log.logarithm(number)

