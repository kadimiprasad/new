from setuptools import setup

setup(
    name='project-dev',
    version='1.0.1',
    packages=['new', 'src', 'src.code', 'src.main', 'test'],
    url='',
    license='',
    data_files=[('.', ["__main__.py"])],
    entry_points={'setuptools.installation':['eggsecutable = src.main.main:main']},
    author='kadimi.prasad',
    author_email='',
    description=''
)
