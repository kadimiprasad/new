import logging

logging.basicConfig(filename="new_log.log",level=logging.ERROR,
                    format='%(asctime)s %(message)s',
                    filemode='w')
logger = logging.getLogger()
