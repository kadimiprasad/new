"""import module"""
import unittest
import src.code.log


class TestStringMethods(unittest.TestCase):
    """Test_valid_number"""

    def test_logarithm(self):
        res = src.code.log.logarithm(100000)
        self.assertEqual(res, 5.0)
    """test_type_of_variable"""

    def test_logarithm2(self):
        res=src.code.log.logarithm(10)
        self.assertTrue(type(res), int)
    """test_for_negative_number"""

    def test_logarithm3(self):
        self.assertRaises(ValueError)

    """test_for_type"""
    def test_logarithm4(self):
        self.assertRaises(TypeError)


if __name__ == '__main__':
    unittest.main()
