
import unittest
import log


class TestStringMethods(unittest.TestCase):

    def test_logarithm2(self):
        self.assertTrue(log.Logarithm1(type(10)), int)
    # test_for_negative_number

    def test_logarithm3(self):
        self.assertRaises(ValueError)

    # test_for_type
    def test_logarithm4(self):
        self.assertRaises(TypeError)


if __name__ == '__main__':
    unittest.main()
